package com.example.main;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import javax.servlet.http.HttpSession;

import com.example.productReg.productController;

@Controller //���� �대���ㅻ�� �ㅽ��留����� 愿�由ы���� 而⑦�몃·�� bean�쇰� ����


public class MainController {
	//濡�源��� ���� 蹂���
	private static final Logger logger = LoggerFactory.getLogger(productController.class);
		
	@RequestMapping(value="/", produces="text/plain;charset=UTF-8")
	public ModelAndView read(HttpSession session) throws Exception{
		ModelAndView mainPage = new ModelAndView("home/home");
		if(session.getAttribute("userId") != null)
			mainPage.addObject("msg", "success");
		else
			mainPage.addObject("msg", "failure");
		return mainPage;
	}
}