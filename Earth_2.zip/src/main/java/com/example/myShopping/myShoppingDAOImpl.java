package com.example.myShopping;

import java.util.List;

import javax.inject.Inject;
import org.apache.ibatis.session.SqlSession;

import org.springframework.stereotype.Repository;

import com.example.myShopping.myShoppingDAO;
import com.example.myShopping.myShoppingVO;

@Repository
public class myShoppingDAOImpl implements myShoppingDAO{
	@Inject
	SqlSession sqlSession;
	
	@Override
	public List<myShoppingVO> listProduct() {
		return sqlSession.selectList("myShopping.listProduct");
	}

	@Override
	public myShoppingVO detailProduct(int productId) {
		return sqlSession.selectOne("myShopping.detailProduct", productId);
	}

	@Override
	public void updateProduct(myShoppingVO vo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteProduct(int productId) {
		// TODO Auto-generated method stub
		
	}
}
