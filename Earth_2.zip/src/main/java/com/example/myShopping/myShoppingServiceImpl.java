package com.example.myShopping;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.example.myShopping.myShoppingDAO;
import com.example.myShopping.myShoppingService;
import com.example.myShopping.myShoppingVO;

@Service
public class myShoppingServiceImpl implements myShoppingService {
	@Inject
	myShoppingDAO productDao;

	@Override
	public List<myShoppingVO> listProduct() {
		return productDao.listProduct();
	}

	@Override
	public myShoppingVO detailProduct(int productId) {
		return productDao.detailProduct(productId);
	}

	@Override
	public void updateProduct(myShoppingVO vo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteProduct(int productId) {
		// TODO Auto-generated method stub
		
	}
}
