package com.example.product;

import java.util.List;

import com.example.product.ProductVO;

public interface ProductDAO {
	public List<ProductVO> listProduct();
	public ProductVO detailProduct(int productId);
	public void updateProduct(ProductVO vo);
	public void deleteProduct(int productId);
}
