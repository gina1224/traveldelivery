package com.example.product;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.example.product.ProductDAO;
import com.example.product.ProductVO;
import com.example.product.ProductService;

@Service
public class ProductServiceImpl implements ProductService {
	@Inject
	ProductDAO productDao;

	@Override
	public List<ProductVO> listProduct() {
		return productDao.listProduct();
	}

	@Override
	public ProductVO detailProduct(int productId) {
		return productDao.detailProduct(productId);
	}

	@Override
	public void updateProduct(ProductVO vo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteProduct(int productId) {
		// TODO Auto-generated method stub
		
	}
}
