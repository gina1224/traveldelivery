package com.example.myShopping;

import java.util.List;

import com.example.myShopping.myShoppingVO;

public interface myShoppingService {
	public List<myShoppingVO> listProduct();
	public myShoppingVO detailProduct(int productId);
	public void updateProduct(myShoppingVO vo);
	public void deleteProduct(int productId);
}
