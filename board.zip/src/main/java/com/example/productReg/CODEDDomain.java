package com.example.productReg;

public class CODEDDomain {
	private int GROUPID;
	private int CODEID;
	private String GROUPNAME;
	private String CODENAME;
	public int getGROUPID() {
		return GROUPID;
	}

	public int getCODEID() {
		return CODEID;
	}

	public String getGROUPNAME() {
		return GROUPNAME;
	}

	public String getCODENAME() {
		return CODENAME;
	}
	
	
}
