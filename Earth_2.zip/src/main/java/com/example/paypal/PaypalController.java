package com.example.paypal;

import javax.inject.Inject;
import com.example.productReg.ProductDomain;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.paypal.PaypalDomain;
import javax.servlet.http.HttpSession;

@RequestMapping("/paypal")
@Controller //���� �대���ㅻ�� �ㅽ��留����� 愿�由ы���� 而⑦�몃·�� bean�쇰� ����
public class PaypalController {
	//濡�源��� ���� 蹂���
	private static final Logger logger = LoggerFactory.getLogger(PaypalController.class);
	
	@Inject
	PaypalService paypalService;
	

	//01.濡�洹몄�� ��硫�
	@RequestMapping("/payment")
	public ModelAndView pay(@RequestParam String pname, @RequestParam String count, @RequestParam String price, HttpSession session){
		ModelAndView mav = new ModelAndView("paypal/paypalStart");
	
		if(session.getAttribute("userId") != null)
			mav.addObject("msg", "success");
		else
			mav.addObject("msg", "failure");
	
		mav.addObject("pname",pname);
		mav.addObject("price",price);
		mav.addObject("amount",count);
		
		mav.addObject("address1", "서울시 강남구 논현로 209");
		mav.addObject("address2","서울 성북구 화랑로13길 60");
		return mav;
	}
	

	

//	@RequestMapping("success")
//	public String paySuccess(){
//		return "paypal/success";
//	}
	// 湲� ���몃낫湲�
	/*
		@GetMapping("/paypal/{UserID}")
		public ModelAndView readOne(@PathVariable("UserID") String UserID) throws Exception{
			List<PaypalDomain> paypalList = paypalService.findByUserID(UserID);
			ModelAndView nextPage = new ModelAndView("paypal/success");
			nextPage.addObject("paypalList", paypalList);
			return nextPage;
		}
*/
	// TEST
	@GetMapping("/test")
	public ModelAndView readTest() throws Exception{
		System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		PaypalDomain paypalItem = paypalService.findByID(1);
		ModelAndView nextPage = new ModelAndView("paypal/success");
		nextPage.addObject("paypalItem", paypalItem);
		return nextPage;
	}
	
		
}